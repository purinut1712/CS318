package cooperative;

import javax.swing.JOptionPane;


public class Home_Frame extends javax.swing.JFrame {


    public Home_Frame() {
        initComponents();
    }


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_deposit = new javax.swing.JButton();
        btn_withdraw = new javax.swing.JButton();
        btn_transfer = new javax.swing.JButton();
        btn_view_balance = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_addCustomer = new javax.swing.JButton();
        btn_editCustomer = new javax.swing.JButton();
        btn_customerList = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btn_transaction = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(56, 229, 77));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("COOPERATIVE");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        btn_deposit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/deposit.png"))); // NOI18N
        btn_deposit.setBorder(null);
        btn_deposit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_depositMouseClicked(evt);
            }
        });

        btn_withdraw.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/withdraw.png"))); // NOI18N
        btn_withdraw.setBorder(null);
        btn_withdraw.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_withdrawMouseClicked(evt);
            }
        });

        btn_transfer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/transfer.png"))); // NOI18N
        btn_transfer.setToolTipText("");
        btn_transfer.setBorder(null);
        btn_transfer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_transferMouseClicked(evt);
            }
        });

        btn_view_balance.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/view_balance.png"))); // NOI18N
        btn_view_balance.setBorder(null);
        btn_view_balance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_view_balanceMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(56, 229, 77));
        jLabel2.setText("DEPOSIT");

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(56, 229, 77));
        jLabel3.setText("WITHDRAW");

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(56, 229, 77));
        jLabel4.setText("TRANSFER");

        jLabel5.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(56, 229, 77));
        jLabel5.setText("VIEW BALANCE");

        btn_addCustomer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/add_user.png"))); // NOI18N
        btn_addCustomer.setBorder(null);
        btn_addCustomer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_addCustomerMouseClicked(evt);
            }
        });

        btn_editCustomer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/customer_edit.png"))); // NOI18N
        btn_editCustomer.setBorder(null);
        btn_editCustomer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_editCustomerMouseClicked(evt);
            }
        });

        btn_customerList.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/customer_list.png"))); // NOI18N
        btn_customerList.setBorder(null);
        btn_customerList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_customerListMouseClicked(evt);
            }
        });

        btn_logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/logout.png"))); // NOI18N
        btn_logout.setBorder(null);
        btn_logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_logoutMouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(56, 229, 77));
        jLabel6.setText("ADD CUSTOMER");

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(56, 229, 77));
        jLabel7.setText("EDIT CUSTOMER");

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(56, 229, 77));
        jLabel8.setText("CUSTOMER LIST");

        jLabel9.setFont(new java.awt.Font("Helvetica Neue", 1, 15)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(56, 229, 77));
        jLabel9.setText("LOGOUT");

        jLabel10.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(56, 229, 77));
        jLabel10.setText("TRANSACTION");

        btn_transaction.setBackground(new java.awt.Color(254, 254, 254));
        btn_transaction.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/transaction-history.png"))); // NOI18N
        btn_transaction.setBorder(null);
        btn_transaction.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_transactionMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_addCustomer)
                            .addComponent(btn_deposit)
                            .addComponent(jLabel6)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(jLabel9))
                                .addComponent(btn_logout)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jLabel7))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel3))
                                    .addComponent(btn_withdraw)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(158, 158, 158))
                            .addComponent(btn_editCustomer))
                        .addGap(10, 10, 10)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_transfer)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel4))
                            .addComponent(btn_customerList))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(65, 65, 65)
                                .addComponent(btn_view_balance)
                                .addGap(0, 2, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel10)
                                        .addComponent(jLabel5))
                                    .addComponent(btn_transaction, javax.swing.GroupLayout.Alignment.TRAILING))))))
                .addGap(81, 81, 81))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_view_balance)
                    .addComponent(btn_withdraw)
                    .addComponent(btn_deposit)
                    .addComponent(btn_transfer))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_editCustomer)
                    .addComponent(btn_addCustomer)
                    .addComponent(btn_customerList)
                    .addComponent(btn_transaction))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addGap(26, 26, 26)
                        .addComponent(btn_logout)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_depositMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_depositMouseClicked
        System.out.println("Deposit Click");
        
        dispose();
        Deposit_Frame deposit = new Deposit_Frame();
        deposit.setVisible(true);
    }//GEN-LAST:event_btn_depositMouseClicked

    private void btn_withdrawMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_withdrawMouseClicked
        System.out.println("Withdraw Click");
        
        dispose();
        Withdraw_Frame withdraw = new Withdraw_Frame();
        withdraw.setVisible(true);
    }//GEN-LAST:event_btn_withdrawMouseClicked

    private void btn_transferMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_transferMouseClicked
        System.out.println("Transfer Click");
        
        dispose();
        Transfer_Frame transfer = new Transfer_Frame();
        transfer.setVisible(true);
    }//GEN-LAST:event_btn_transferMouseClicked

    private void btn_view_balanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_view_balanceMouseClicked
        System.out.println("View Balance Click");
        
        dispose();
        ViewBalance_Frame view_balance = new ViewBalance_Frame();
        view_balance.setVisible(true);
    }//GEN-LAST:event_btn_view_balanceMouseClicked

    private void btn_addCustomerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_addCustomerMouseClicked
        System.out.println("Add Customer Click");
        
        dispose();
        AddCustomer_Frame add_customer = new AddCustomer_Frame();
        add_customer.setVisible(true);
    }//GEN-LAST:event_btn_addCustomerMouseClicked

    private void btn_editCustomerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_editCustomerMouseClicked
        System.out.println("Edit Customer Click");
        
        dispose();
        EditCustomer_Frame edit_customer = new EditCustomer_Frame();
        edit_customer.setVisible(true);
    }//GEN-LAST:event_btn_editCustomerMouseClicked

    private void btn_customerListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_customerListMouseClicked
        System.out.println("Customer List Click");
        
        dispose();
        CustomerList_Frame customer_list = new CustomerList_Frame();
        customer_list.setVisible(true);
    }//GEN-LAST:event_btn_customerListMouseClicked

    private void btn_logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_logoutMouseClicked
        int n = JOptionPane.showConfirmDialog(
	    null,
	    "Logout ?",
	    "System",
	    JOptionPane.YES_NO_OPTION);
        if(n==0){
            dispose();
            Login_Frame login = new Login_Frame();
            login.setVisible(true);
            
            System.out.println("Logout Click");
        }

    }//GEN-LAST:event_btn_logoutMouseClicked

    private void btn_transactionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_transactionMouseClicked
        // TODO add your handling code here:
        dispose();
        Transaction_Frame frame = new Transaction_Frame();
        frame.setVisible(true);
    }//GEN-LAST:event_btn_transactionMouseClicked

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home_Frame().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_addCustomer;
    private javax.swing.JButton btn_customerList;
    private javax.swing.JButton btn_deposit;
    private javax.swing.JButton btn_editCustomer;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_transaction;
    private javax.swing.JButton btn_transfer;
    private javax.swing.JButton btn_view_balance;
    private javax.swing.JButton btn_withdraw;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
