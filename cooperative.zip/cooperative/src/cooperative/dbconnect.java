package cooperative;

import java.sql.*;


/**
 *
 * @author user
 */
public class dbconnect {
    Connection conn = null;
    
    public static Connection connectDB(){ //connectDB() วิธีการส่งกลับวัตถุการเชื่อมต่อที่สามารถใช้เพื่อโต้ตอบกับฐานข้อมูล
        try{
            
            Class.forName("org.sqlite.JDBC"); //โหลดไดรเวอร์ SQLite JDBC ซึ่งจำเป็นในการสร้างการเชื่อมต่อกับฐานข้อมูล
            Connection conn = DriverManager.getConnection("jdbc:sqlite:cooperative_database.sqlite"); //สร้างการเชื่อมต่อฐานข้อมูล
            
            System.out.println("Connection Successful");
            
            return conn;
            
        }catch(Exception e){
            System.err.println("Connection Failed :" + e);
            
            return null;
        }
        
    }
}
