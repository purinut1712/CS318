package cooperative;

/**
 *
 * @author user
 */
public class Cooperative {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        dbconnect connect = new dbconnect();
        connect.connectDB();
        
        Login_Frame login = new Login_Frame();
        login.setVisible(true);
        //Home_Frame main = new Home_Frame();
        //main.setVisible(true);
        
    }
    
}
