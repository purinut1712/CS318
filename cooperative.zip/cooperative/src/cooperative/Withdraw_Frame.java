package cooperative;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

/**
 *
 * @author peach
 */
public class Withdraw_Frame extends javax.swing.JFrame {
    Connection conn;
    ResultSet rs;
    PreparedStatement pst, pst_balance,pst_tran;

    /**
     * Creates new form Withdraw_Frame
     */
    public Withdraw_Frame() {
        initComponents();
        conn = dbconnect.connectDB();
        
        txt_customerID.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txt_creditID = new javax.swing.JTextField();
        btn_search = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txt_name = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_viewBalance = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_withdraw = new javax.swing.JTextField();
        txt_calculate = new javax.swing.JTextField();
        btn_calculate = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_detail = new javax.swing.JTextArea();
        btn_withdraw = new javax.swing.JButton();
        txt_customerID = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(56, 229, 77));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("WITHDRAW");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(290, 290, 290))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        btn_back.setBackground(new java.awt.Color(251, 251, 251));
        btn_back.setForeground(new java.awt.Color(56, 229, 77));
        btn_back.setText("Back");
        btn_back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_backMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel2.setText("Credit ID");

        txt_creditID.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btn_search.setBackground(new java.awt.Color(251, 251, 251));
        btn_search.setText("search");
        btn_search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_searchMouseClicked(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel3.setText("Name");

        txt_name.setEditable(false);
        txt_name.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel4.setText("Available Balance");

        txt_viewBalance.setEditable(false);
        txt_viewBalance.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel5.setText("Withdraw Amount");

        txt_withdraw.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        txt_calculate.setEditable(false);
        txt_calculate.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btn_calculate.setBackground(new java.awt.Color(251, 251, 251));
        btn_calculate.setText("Calculate");
        btn_calculate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_calculateMouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel6.setText("Detail");

        txt_detail.setColumns(20);
        txt_detail.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txt_detail.setRows(5);
        jScrollPane1.setViewportView(txt_detail);

        btn_withdraw.setBackground(new java.awt.Color(251, 251, 251));
        btn_withdraw.setText("Withdraw");
        btn_withdraw.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_withdrawMouseClicked(evt);
            }
        });

        txt_customerID.setEditable(false);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        jLabel7.setText("Calculate Balance");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_back)
                .addContainerGap(733, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btn_withdraw)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_viewBalance, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_name, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_creditID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_customerID, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_withdraw)
                            .addComponent(txt_calculate, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_calculate)))
                .addGap(179, 179, 179))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_creditID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_search))
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_customerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_viewBalance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_withdraw, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_calculate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_calculate)))
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_withdraw)
                .addGap(17, 17, 17)
                .addComponent(btn_back)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_backMouseClicked
    System.out.println("Back Click");

    dispose();
    Home_Frame main = new Home_Frame();
    main.setVisible(true);
    }//GEN-LAST:event_btn_backMouseClicked

    private void btn_searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_searchMouseClicked
        System.out.println("Search Click");
        
        String balance_sql = "SELECT * FROM Customer WHERE customer_creditID = ?";
        try{
            pst = conn.prepareStatement(balance_sql);
            pst.setString(1,txt_creditID.getText());
            rs = pst.executeQuery();
            if(rs.next()){
                String add1 = rs.getString("customer_balance");
                txt_viewBalance.setText(add1);
                
                String add2 = rs.getString("customer_name");
                txt_name.setText(add2);
                
                String add3 = rs.getString("customer_id");
                txt_customerID.setText(add3);
                

                rs.close();
                pst.close();
            }else{
                JOptionPane.showMessageDialog(null,"INcorrect creditID, please try again.");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }//GEN-LAST:event_btn_searchMouseClicked

    private void btn_calculateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_calculateMouseClicked
        try{
            String sum = calculate();
            txt_calculate.setText(sum);
            
        }catch(Exception NumberFormatException){
            //JOptionPane.showMessageDialog(null,"Please enter numbers only"+NumberFormatException);
            JOptionPane.showMessageDialog(null,"Enter your credit ID");
        }
    }//GEN-LAST:event_btn_calculateMouseClicked

    private void btn_withdrawMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_withdrawMouseClicked

            String sum = calculate();

            try{

                String sql = "insert into Banking(bk_id, bk_name, bk_balance, bk_withdraw,bk_detail, bk_date, bk_time, bk_customerID) values(?,?,?,?,?,?,?,?)";
                String updatebalance_sql =  "UPDATE Customer SET customer_balance = ? WHERE customer_creditID = ?";
                String transaction_sql = "UPDATE Transaction_database SET tran_withdraw = ? WHERE tran_creditID = ?";

                    GregorianCalendar cal = new GregorianCalendar();

                    pst = conn.prepareStatement(sql);
                    pst.setString(1, txt_creditID.getText());
                    pst.setString(2, txt_name.getText());
                    pst.setString(3, sum);
                    pst.setString(4, txt_withdraw.getText());
                    pst.setString(5, txt_detail.getText());            
                    pst.setString(6, cal.get(Calendar.DATE) + "/" + cal.get(Calendar.MONTH) + "/" + cal.get(Calendar.YEAR));
                    pst.setString(7, cal.get(Calendar.HOUR_OF_DAY)+":"+cal.get(Calendar.MINUTE)+":"+cal.get(Calendar.SECOND));
                    pst.setString(8, txt_customerID.getText());   

                    pst.execute();
                    pst.close();

                    //Update balance of Customer Table
                    pst_balance = conn.prepareStatement(updatebalance_sql);
                    pst_balance.setString(1, sum);
                    pst_balance.setString(2, txt_creditID.getText());

                    pst_balance.executeUpdate();
                    pst_balance.close();
                    
                    tran_withdraw();

                     JOptionPane.showMessageDialog(null,"Withdraw Success.");

                     txt_creditID.setText("");
                     txt_name.setText("");
                     txt_viewBalance.setText("");
                     txt_withdraw.setText("");
                     txt_calculate.setText("");
                     txt_detail.setText("");
                     txt_customerID.setText("");

            }catch(Exception e){
                JOptionPane.showMessageDialog(null,e);
            }
    }//GEN-LAST:event_btn_withdrawMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Withdraw_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Withdraw_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Withdraw_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Withdraw_Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Withdraw_Frame().setVisible(true);
            }
        });
    }
    
    public String calculate(){
        String a1 = txt_viewBalance.getText();
        String a2 = txt_withdraw.getText();
        double sum = Double.parseDouble(a1) - Double.parseDouble(a2);
        String sum1 = Double.toString(sum);
        return sum1;
    }
    
    public void tran_withdraw(){
        String select_sql = "SELECT tran_withdraw FROM Transaction_database WHERE tran_creditID = ?";
        String update_sql = "UPDATE Transaction_database SET tran_withdraw = ? WHERE tran_creditID = ?";
        try{
            pst = conn.prepareStatement(select_sql);
            pst.setString(1,txt_creditID.getText());
            rs = pst.executeQuery();

        if (rs.next()) {
            int count = rs.getInt("tran_withdraw");
            double sum = Double.parseDouble(txt_withdraw.getText())+count;
            System.out.println("SUM withdraw: "+sum);
            
            pst_tran = conn.prepareStatement(update_sql);
            pst_tran.setString(1,Double.toString(sum));
            pst_tran.setString(2, txt_creditID.getText());

            pst_tran.executeUpdate();
            
        }



        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Catch Error 1 :" + e);
        }finally{
            try{
                rs.close();
                pst.close();
                pst_tran.close();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Catch Error 2  "+ e);
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_calculate;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_withdraw;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txt_calculate;
    private javax.swing.JTextField txt_creditID;
    private javax.swing.JTextField txt_customerID;
    private javax.swing.JTextArea txt_detail;
    private javax.swing.JTextField txt_name;
    private javax.swing.JTextField txt_viewBalance;
    private javax.swing.JTextField txt_withdraw;
    // End of variables declaration//GEN-END:variables
}
